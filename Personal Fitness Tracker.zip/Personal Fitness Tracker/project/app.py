import streamlit as st
import hashlib
import time
from datetime import date, timedelta
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from hashlib import sha256

# Path for the Excel file
EXCEL_FILE = "users.xlsx"

# Function to load user data from Excel
def load_users():
    try:
        df = pd.read_excel(EXCEL_FILE)
        if "Username" not in df.columns:
            raise KeyError("The required column 'Username' is missing.")
        return df.set_index("Username").to_dict(orient="index")
    except (FileNotFoundError, KeyError):
        df = pd.DataFrame(columns=["Username", "Password", "Last_Attendance"])
        df.to_excel(EXCEL_FILE, index=False)
        return {}

# Function to save user data to Excel
def save_users(users_dict):
    df = pd.DataFrame.from_dict(users_dict, orient="index").reset_index()
    expected_columns = ["Username", "Password", "Last_Attendance"] + [col for col in df.columns if col not in ["index", "Password", "Last_Attendance", "Username"]]
    df.columns = expected_columns
    df.to_excel(EXCEL_FILE, index=False)

# Function to hash passwords
def hash_password(password):
    return sha256(password.encode()).hexdigest()

# Function to check login credentials
def check_login(username, password, users):
    if username in users and users[username]["Password"] == hash_password(password):
        return True
    return False

# Function to add new users
def add_user(username, password, users):
    if username not in users:
        users[username] = {"Password": hash_password(password), "Last_Attendance": None}
        save_users(users)

# Function to delete a user account
def delete_account(username, users):
    if username in users:
        del users[username]
        save_users(users)
        return True
    return False

# Function to mark attendance
def mark_attendance(username, users):
    today = str(date.today())
    if username in users:
        if users[username]["Last_Attendance"] != today:
            users[username]["Last_Attendance"] = today
            save_users(users)
            return True  # Attendance marked successfully
        return False  # Attendance already marked today

# MET values for calorie burn activities
ACTIVITY_MET = {
    "Yoga": 3.0,
    "Karate": 10.0,
    "Running (6 mph)": 9.8,
    "Cycling (moderate)": 7.5,
    "Swimming": 8.0,
    "Jump Rope": 12.0,
    "Hiking": 6.0,
    "Rowing": 7.0,
    "Weightlifting": 6.0,
    "Dancing": 5.0,
    "Pilates": 4.0,
    "Zumba": 6.5,
    "Basketball": 8.0,
    "Soccer": 10.0,
    "Tennis": 7.3,
    "Badminton": 5.5,
    "Volleyball": 4.0,
    "Elliptical Trainer": 5.0,
    "Stair Climbing": 8.8,
    "Rowing Machine": 6.5,
    "Golf (walking)": 4.8,
    "Skiing": 7.5,
    "Ice Skating": 7.0,
    "Horse Riding": 6.0,
    "Jumping Jacks": 8.0,
    "Push-Ups": 5.5,
    "Pull-Ups": 6.0,
    "Squats": 5.0,
    "Lunges": 5.3,
    "Martial Arts": 11.0,
    "Archery": 3.5,
    "Rock Climbing": 9.5,
    "Canoeing": 5.0,
    "Surfing": 4.0,
    "Scuba Diving": 7.0,
    "Frisbee": 3.0,
    "Table Tennis": 4.0,
    "Bowling": 3.8,
    "Fencing": 6.0,
    "Handball": 9.0,
    "Lacrosse": 8.5,
    "Rugby": 10.5,
    "Cricket": 4.5,
    "Skateboarding": 5.0,
    "Parkour": 10.0,
    "Jumping Rope (Fast)": 14.0,
    "Tai Chi": 3.0,
    "Walking (3 mph)": 3.5,
    "Standing Desk Work": 2.0
}

# Initialize the app
users = load_users()

if 'login' not in st.session_state:
    st.session_state.login = False
    st.session_state.current_user = None

if not st.session_state.login:
    # Login/Signup Page
    st.title("Login/Signup")
    option = st.radio("Select an option", ["Login", "Signup"])
    
    username = st.text_input("Username").strip()
    password = st.text_input("Password", type="password").strip()
    
    if option == "Login":
        if st.button("Login"):
            if not username or not password:
                st.error("Please enter both username and password.")
            elif check_login(username, password, users):
                st.session_state.login = True
                st.session_state.current_user = username
                st.success(f"Welcome back, {username}!")
            else:
                st.error("Invalid username or password.")
    
    elif option == "Signup":
        if st.button("Signup"):
            if not username or not password:
                st.error("Please enter both username and password.")
            elif username in users:
                st.error("Username already exists. Please choose another.")
            else:
                add_user(username, password, users)
                st.success("Registration successful! Please log in.")
else:
    # Main Content (Only after login)
    st.title("Personal Fitness Tracker")

    username = st.session_state.current_user
    st.write(f"Hello, {username}! Welcome to your personal fitness tracker.")
    
    if st.button("Mark Attendance"):
        if mark_attendance(username, users):
            st.success("Attendance marked successfully!")
        else:
            st.warning("You have already marked attendance for today.")
    st.write("---")
        # Define the herbal information divided into 5 topics (10 herbs each)
    herbal_info = {
        "Adaptogens & Energy Enhancers": {
            "Ashwagandha": "Ashwagandha may help reduce stress and improve energy levels.",
            "Panax Ginseng": "Panax Ginseng boosts endurance and vitality.",
            "Rhodiola Rosea": "Rhodiola Rosea helps combat fatigue and enhances performance.",
            "Maca Root": "Maca Root is known to improve stamina and hormonal balance.",
            "Schisandra Chinensis": "Schisandra supports endurance through its adaptogenic properties.",
            "Cordyceps sinensis": "Cordyceps may enhance oxygen utilization and boost energy.",
            "Eleuthero (Siberian Ginseng)": "Eleuthero supports stamina and stress resilience.",
            "Suma Root": "Suma Root is traditionally used to support overall vitality.",
            "Tongkat Ali": "Tongkat Ali is known for boosting testosterone and strength.",
            "Ashitaba": "Ashitaba provides antioxidants and may support metabolism."
        },
        "Recovery & Anti-inflammatory": {
            "Turmeric": "Turmeric is celebrated for its anti-inflammatory and recovery benefits.",
            "Ginger": "Ginger can reduce muscle soreness and aid digestion.",
            "Reishi Mushroom": "Reishi Mushroom supports immune health and recovery.",
            "Lion’s Mane Mushroom": "Lion’s Mane assists in cognitive support and recovery.",
            "Milk Thistle": "Milk Thistle promotes liver health and detoxification.",
            "Dandelion Root": "Dandelion Root aids in detoxification and supports recovery.",
            "Triphala": "Triphala helps maintain digestive balance and detoxification.",
            "Nettle Leaf": "Nettle Leaf has anti-inflammatory properties that aid recovery.",
            "Burdock Root": "Burdock Root supports detoxification and overall wellness.",
            "Cinnamon": "Cinnamon provides antioxidants and supports metabolism."
        },
        "Performance & Metabolic Support": {
            "Tribulus Terrestris": "Tribulus Terrestris is popular for supporting muscle strength and hormones.",
            "Fenugreek": "Fenugreek can help enhance muscle performance and maintain healthy testosterone levels.",
            "Mucuna Pruriens": "Mucuna Pruriens may improve dopamine levels and overall performance.",
            "Rhaponticum Carthamoides": "Maral Root supports muscle strength and endurance.",
            "Cayenne Pepper": "Cayenne Pepper stimulates metabolism and improves circulation.",
            "Green Coffee Bean Extract": "Green Coffee Bean Extract aids metabolism and fat oxidation.",
            "Bitter Melon": "Bitter Melon supports healthy glucose metabolism.",
            "Grape Seed Extract": "Grape Seed Extract offers antioxidants and supports recovery.",
            "Cardamom": "Cardamom aids digestion and has metabolic benefits.",
            "Rooibos Tea Extract": "Rooibos Tea Extract can promote relaxation and support metabolism."
        },
        "Circulation, Immune & Detox": {
            "Garlic": "Garlic improves cardiovascular health and bolsters immune function.",
            "Green Tea": "Green Tea is rich in antioxidants and supports metabolic functions.",
            "Ginkgo Biloba": "Ginkgo Biloba enhances blood flow and cognitive performance.",
            "Pine Bark Extract": "Pine Bark Extract (Pycnogenol) supports circulation and reduces inflammation.",
            "Beetroot Extract": "Beetroot Extract improves blood flow and boosts stamina.",
            "Gotu Kola": "Gotu Kola helps improve circulation and mental clarity.",
            "Holy Basil (Tulsi)": "Holy Basil supports immune health and reduces stress.",
            "Saffron Extract": "Saffron Extract improves mood and supports digestion.",
            "Olive Leaf Extract": "Olive Leaf Extract is known for its immune-supportive and antioxidant properties.",
            "Camu Camu": "Camu Camu is high in vitamin C and supports immune function."
        },
        "Fungi & Miscellaneous Wellness": {
            "Baobab Fruit Powder": "Baobab is nutrient-dense and supports overall energy and recovery.",
            "Bacopa Monnieri": "Bacopa Monnieri supports cognitive function and stress management.",
            "Shilajit": "Shilajit is rich in minerals and can help boost energy and endurance.",
            "Astragalus membranaceus": "Astragalus supports immune function and overall vitality.",
            "Maitake Mushroom": "Maitake Mushroom enhances immune response and wellness.",
            "Cordyceps militaris": "Cordyceps militaris may improve athletic performance and stamina.",
            "Goldenseal": "Goldenseal supports immune health and aids in digestion.",
            "Amla (Indian Gooseberry)": "Amla is packed with vitamin C and supports recovery and immunity.",
            "Moringa Oleifera": "Moringa is highly nutritious and supports energy levels.",
            "Gynostemma pentaphyllum": "Gynostemma (Jiaogulan) aids in endurance and stress management."
        }
    }

    st.title("Herbal Allies for Peak Fitness")

# Sidebar components for category and herb selection
    st.sidebar.header("Herbals Used In Fitness: ")
    selected_category = st.sidebar.selectbox("Select a Herbal Category", list(herbal_info.keys()))
    selected_herb = st.sidebar.selectbox("Select a Herb", list(herbal_info[selected_category].keys()))

# Display the selected herb's information
    st.header(f"Information On: {selected_herb}")
    st.write(herbal_info[selected_category][selected_herb])


    # Calories Burned Calculator Section
    st.write("---")
    st.header("Calories Burned Calculator")
    weight = st.number_input("Enter your weight (kg):", min_value=30, max_value=200, value=70)
    activity = st.selectbox("Select an activity:", list(ACTIVITY_MET.keys()))
    duration = st.selectbox("Select duration (minutes):", [15, 30, 45, 60, 90, 120])

    if activity and duration:
        met_value = ACTIVITY_MET[activity]
        calories_burned = met_value * weight * (duration / 60)  # Duration is in minutes
        st.success(f"You burned approximately {calories_burned:.2f} calories.")
    st.write("---")
    st.title("Personalized Home Workout Plans for Muscle Gain & Fitness")


    men_workouts = {
    "Muscle Gain & Strength": {
        "Beginner Full-Body Strength (No Equipment)": (
            "This plan is designed for beginners. It focuses on building a solid foundation by using bodyweight exercises "
            "that target all major muscle groups. Warm-up with dynamic stretches, then perform sets of push-ups, squats, "
            "lunges, and planks. Finish with a cool-down."
        ),
        "Advanced Full-Body Strength (Dumbbells & Resistance Bands)": (
            "This advanced plan uses dumbbells and resistance bands to boost muscle mass and strength. Focus on progressive "
            "overload while performing compound movements and controlled isolation exercises."
        ),
        "Push-Pull Routine (Upper & Lower Body Split)": (
            "In this plan, you'll alternate between push and pull muscle groups. The routine is split into two parts to allow "
            "for maximum recovery and muscle growth."
        ),
        "Bodyweight Power Builder (Calisthenics-Based)": (
            "A calisthenics-based program that leverages your bodyweight to develop power and strength. Ideal for those "
            "seeking to improve functional fitness with explosive moves."
        ),
        "Strength & Endurance Hybrid (Circuit Training)": (
            "This circuit-training plan is designed to build both strength and endurance by combining traditional strength movements "
            "with high-intensity intervals."
        ),
        "Explosive Strength (Plyometrics & Core)": (
            "Focus on explosive and plyometric exercises to rapidly increase power. Coupled with core work, this plan takes your training to new heights."
        ),
        "Chest & Arm Mass Builder (Push-Ups & Weights)": (
            "Target your chest and arms with heavy push-ups variations and weighted exercises to build significant muscle mass in a focused area."
        ),
        "Leg Day at Home (Squats, Lunges, Jumps)": (
            "A dedicated leg workout plan that emphasizes squats, lunges, and plyometric jumps to create lower body strength and power."
        ),
        "Athlete Power Training (Speed & Agility)": (
            "Built for the athlete in you! This routine focuses on speed, agility, and explosive power through sprint intervals, agility drills, and plyometrics."
        ),
        "Gymnastic Strength (Handstands, L-Sits, Planche Basics)": (
            "Inspired by gymnastics, this plan uses advanced bodyweight exercises like handstands, L-sits, and planche progressions to build incredible strength and control."
        )
    },
    "Fat Loss & Cardio": {
        "HIIT for Fat Burn (15-30 Min Circuits)": (
            "A high-intensity interval training (HIIT) plan focused on burning fat quickly through short bursts of intense exercise followed by brief rest periods."
        ),
        "Boxing & Kickboxing Drills (Shadowboxing & Cardio)": (
            "Combine the benefits of boxing and kickboxing with cardio drills. Expect intense shadowboxing rounds mixed with footwork drills."
        ),
        "Bodyweight HIIT (No Equipment, Max Burn)": (
            "This equipment-free HIIT plan uses bodyweight exercises exclusively to create a high-calorie-burning workout session."
        ),
        "Jump Rope Challenge (Conditioning & Footwork)": (
            "Use a jump rope to improve your conditioning and footwork. This plan revolves around varied jump rope techniques to keep your heart rate high."
        ),
        "Tabata Fat Burner (4-Min Rounds)": (
            "Adopt the Tabata protocol for a quick but extremely efficient fat-burning workout. Perfect if you’re short on time but need maximum results."
        ),
        "Running Alternative: Agility & Sprints": (
            "If you’re unable to run outside, this plan uses short sprints and agility drills to simulate running benefits while indoors."
        ),
        "Core & Cardio Fusion (Abs & Fat Loss)": (
            "A blend of core exercises and cardio sessions designed to build abdominal strength while torching calories."
        ),
        "Athletic Conditioning (Quickness & Endurance)": (
            "Focus on overall athletic conditioning with drills that enhance quickness, agility, and endurance simultaneously."
        ),
        "Kettlebell Shred (Full-Body Strength & Burn)": (
            "Incorporate kettlebell exercises that combine strength training with high-intensity cardio for a full-body fat-burn and muscle-sculpting routine."
        ),
        "Burpee Madness (Extreme Fat Burn)": (
            "A plan built around the classic burpee exercise. Intensify your workout with high rep burpee circuits for an extreme calorie burn."
        )
    },
    "Functional Fitness & Mobility": {
        "Full-Body Mobility & Stretching Routine": (
            "Improve your range of motion with a comprehensive mobility routine that emphasizes dynamic and static stretching exercises."
        ),
        "Joint Strength & Stability Plan": (
            "Designed to build joint stability, this plan includes exercises to strengthen muscles around the joints to prevent injuries."
        ),
        "Everyday Functional Fitness (For Lifelong Strength)": (
            "This plan focuses on functional movements that translate into everyday actions, ensuring you not only build muscle but also enhance overall flexibility and balance."
        ),
        "Martial Arts Conditioning (Balance & Power)": (
            "Inspired by martial arts training, this workout emphasizes balance, power, and flexibility through a series of controlled, explosive exercises."
        ),
        "Core & Posture Fix (Back & Abs)": (
            "A workout that combines core strengthening with posture-improving exercises to support back health and improve overall alignment."
        ),
        "Knees Over Toes Training (Bulletproof Joints)": (
            "Focus on strengthening the muscles around your knees using safety-first progressive overload techniques to build bulletproof joints."
        ),
        "Athletic Recovery & Active Stretching": (
            "Incorporate active stretching and recovery drills in your routine to reduce soreness and improve muscular elasticity."
        ),
        "Yoga for Men (Flexibility & Strength)": (
            "A yoga-inspired routine that provides a blend of flexibility and strength training, ideal for increasing overall mobility."
        ),
        "Movement Mastery (Coordination & Agility)": (
            "Work on improving your coordination and agility with exercises that require nimble footwork and balanced movement."
        ),
        "Low-Impact Workout (For Injury Recovery & Beginners)": (
            "A gentle, low-impact workout designed for people recovering from injuries or those new to exercise, focusing on gradual improvement and injury prevention."
        )
    },
    "Advanced & Hybrid Training": {
        "Prison-Style Training (No Equipment, High Volume)": (
            "An intense, high-volume bodyweight routine mimicking prison workouts that require no equipment but demand maximum effort."
        ),
        "100 Rep Challenge (Muscle Endurance)": (
            "Push your muscle endurance to the limit with this 100-rep challenge plan, testing your strength and stamina in one session."
        ),
        "Isometric Strength (Holding & Resistance)": (
            "Focus on isometric exercises where you hold positions to build strength and stability without heavy weights."
        ),
        "Handstand Training Plan": (
            "A specialized plan designed to gradually build the strength, balance, and technique required for handstand work."
        ),
        "Home CrossFit Challenge": (
            "Experience the intensity of CrossFit workouts in your living room with compound, high-intensity movements."
        ),
        "Explosive Plyometric Workout": (
            "Boost your power output using explosive plyometric exercises to improve speed, jump height, and overall athletic performance."
        ),
        "Animal Flow & Functional Strength": (
            "Emulate animal movements in your workout to develop core strength, mobility, and functional fitness."
        ),
        "Resistance Band Full-Body Plan": (
            "Use resistance bands for a full-body workout that challenges your muscles through a broad range of motion."
        ),
        "Strength & Cardio Hybrid (Metabolic Boost)": (
            "Combine traditional strength training with short bursts of cardio to create a workout that improves both muscle mass and cardiovascular fitness."
        ),
        "Hybrid Beast Mode (Strength, Speed, & Endurance)": (
            "A comprehensive training plan that merges strength, speed, and endurance training into one challenging session."
        )
    },
    "Special Focus Plans": {
        "Beginner-to-Advanced Home Progression": (
            "A dynamic plan designed to start at a beginner level and progressively challenge you as you advance over time."
        ),
        "Military Fitness Training (Endurance & Strength)": (
            "Inspired by military training routines, this plan focuses on performing functional strength and endurance drills."
        ),
        "Football & Basketball Conditioning": (
            "A plan tailored towards athletes, incorporating drills that improve speed, agility, and overall conditioning specific to sports."
        ),
        "Dumbbell-Only Strength Program": (
            "Focus solely on dumbbell exercises to develop strength and muscle mass with a variety of upper and lower body movements."
        ),
        "Advanced Calisthenics (Pull-Ups, Dips, Planche)": (
            "A challenging routine for those proficient in bodyweight exercises, emphasizing advanced movements like pull-ups, dips, and planche progressions."
        ),
        "Abdominal Shredder (6-Pack Blueprint)": (
            "Target your core and sculpt your abs with a plan dedicated to high-intensity abdominal exercises and core stabilization workouts."
        ),
        "Jump Higher (Vertical Leap Training)": (
            "Develop explosive leg power and improve your vertical jump through plyometrics and leg strength exercises."
        ),
        "Grip & Forearm Strength (Climbers & Lifters)": (
            "Enhance your grip strength and forearm power with targeted exercises designed for climbers and heavy lifters alike."
        ),
        "Old-School Strongman Routine": (
            "Inspired by the traditional strongman workouts, this plan focuses on functional strength and heavy lifting with bodyweight and simple equipment."
        ),
        "Hybrid Warrior (Strength + Combat Training)": (
            "A unique blend of strength training and combat-inspired drills that boost both power and agility for an overall killer workout."
        )
    }
    }

    women_workouts = {
    "Toning & Fat Loss": {
        "Full-Body Tone & Sculpt (No Equipment)": (
            "This plan aims to tone and sculpt the entire body with bodyweight exercises and calibrated movements to maximize fat loss while enhancing muscle definition."
        ),
        "HIIT Fat Burn (High-Intensity Circuits)": (
            "A high-intensity interval training routine that alternates between bursts of maximal effort and rest to torch calories and shed unwanted fat."
        ),
        "Pilates Core & Leg Sculpt": (
            "Blend Pilates techniques with targeted leg exercises to strengthen your core and achieve a lean, toned lower body."
        ),
        "Dance Cardio (Fun & Sweat)": (
            "A dynamic, dance-inspired cardio workout that makes burning fat enjoyable while boosting rhythm and coordination."
        ),
        "Yoga Burn (Strength & Flexibility)": (
            "Combine yoga poses with strength exercises for a dual focus on flexibility and moderate muscle toning."
        ),
        "Ballet-Inspired Toning Workout": (
            "Inspired by ballet movements, this plan enhances posture, flexibility, and muscle tone through graceful yet effective exercises."
        ),
        "Glutes & Thighs Focus (Lower Body Shape)": (
            "Specifically designed to sculpt and tone the glutes and thighs using targeted bodyweight and resistance exercises."
        ),
        "Kickboxing Cardio Burn": (
            "Integrate kickboxing moves into your workout for an intense cardio session that also tones the upper and lower body."
        ),
        "Quick 15-Minute Fat Loss Routine": (
            "A rapid, efficient circuit that can be done in 15 minutes to kick-start your metabolism and accelerate fat loss."
        ),
        "Core & Waist Slimming (Targeted Abs & Obliques)": (
            "Focus on isolating the abs and obliques with targeted exercises that help create a slimmer waistline and stronger core."
        )
    },
    "Strength & Muscle Building": {
        "Dumbbell Full-Body Strength Plan": (
            "A comprehensive plan utilizing dumbbells to target every muscle group for full-body strength gains and balanced muscle development."
        ),
        "Leg & Booty Builder (Squats & Resistance Bands)": (
            "Emphasize lower body strength and shape your glutes with squats, resistance band exercises, and progressive overload techniques."
        ),
        "Upper Body Strength (Arms, Back & Shoulders)": (
            "Dedicated to building upper body power, this plan involves targeted exercises for the arms, back, and shoulders using dumbbells and bodyweight moves."
        ),
        "Glute Activation & Growth Plan": (
            "A focused routine that employs specific exercises designed to activate and grow the glutes for enhanced lower body strength and aesthetics."
        ),
        "Resistance Band Home Workout": (
            "Utilize resistance bands in a variety of exercises to enhance muscle strength and tone across the entire body."
        ),
        "Total-Body Dumbbell Sculpt": (
            "A full-body routine that combines dumbbell exercises with bodyweight moves for a balanced approach to strength and muscle sculpting."
        ),
        "Strong & Lean (Full-Body Resistance)": (
            "This workout alternates between resistance exercises and cardio bursts, emphasizing lean muscle development and endurance."
        ),
        "Barre Strength & Toning": (
            "Incorporate elements from ballet and Pilates in a barre-inspired routine that emphasizes small, controlled movements for superior toning."
        ),
        "Progressive Strength Plan (From Beginner to Advanced)": (
            "A dynamic program that allows you to progress gradually through different intensity levels as your strength and endurance improve."
        ),
        "Bodyweight Strength Training (Functional & Effective)": (
            "Designed to enhance functional strength using only your bodyweight, this plan is effective for building lean muscle and improving balance."
        )
    },
    "Core & Posture Improvement": {
        "Flat Stomach & Core Strength (Pilates + Abs)": (
            "Combining Pilates with abs-focused exercises, this plan targets the entire core to help achieve a flatter stomach and improved posture."
        ),
        "Lower Back & Posture Fix Workout": (
            "Focus on strengthening and rehabilitating the lower back with exercises that correct posture and reduce discomfort."
        ),
        "Standing Abs & Core Routine": (
            "A unique standing routine that engages the core and abs without requiring you to sit or lie down, ideal for those seeking variety."
        ),
        "Yoga & Mobility for a Strong Core": (
            "Integrate gentle yoga and dynamic core exercises to build a resilient core while increasing overall flexibility."
        ),
        "Waist Shaping & Strengthening": (
            "Target your obliques and deep core muscles to help shape and strengthen your waistline for improved aesthetics and balance."
        ),
        "Plank Challenge (Core & Endurance)": (
            "Push your core endurance with various plank challenges that target multiple muscle groups simultaneously."
        ),
        "Low-Impact Core Workout (Beginner-Friendly)": (
            "A gentle, low-impact workout focusing on the core that’s friendly for beginners or anyone recovering from injury."
        ),
        "Gymnastics Core Strength Routine": (
            "Inspired by gymnastics training, this plan develops core strength with dynamic movements that require control and balance."
        ),
        "Dynamic Core Training (Athletic Abs)": (
            "A fast-paced, athletic core workout that moves beyond static exercises to include dynamic, functional movements."
        ),
        "Prenatal & Postnatal Core Recovery Plan": (
            "Specifically designed for new and expecting mothers, this routine focuses on safely strengthening and rehabilitating the core."
        )
    },
    "Flexibility & Recovery": {
        "Morning Stretch Routine": (
            "Begin your day with a gentle stretching routine that improves flexibility and primes your body for the day’s activities."
        ),
        "Evening Relaxation Yoga": (
            "Wind down your day with a calming yoga sequence focused on gentle movements and deep relaxation."
        ),
        "Full-Body Mobility Plan": (
            "Enhance your mobility and overall range of motion with a series of full-body exercises combined with stretching."
        ),
        "Deep Stretch & Recovery Routine": (
            "This plan uses prolonged stretching and recovery techniques to improve muscle elasticity and reduce soreness."
        ),
        "Active Rest Day Plan": (
            "For days when you’re not training intensely, follow this routine to keep your muscles flexible while promoting recovery."
        ),
        "Lower Body Flexibility Boost": (
            "A focused routine for improving flexibility in your legs, hips, and lower back to reduce tightness and improve movement."
        ),
        "Hip Mobility & Glute Activation": (
            "Emphasize gentle hip stretches combined with glute activation exercises to improve lower body fluidity."
        ),
        "Yoga for Stress Relief": (
            "A yoga plan emphasizing stress relief, deep breathing, and light stretching for holistic recovery."
        ),
        "Breathwork & Recovery Meditation": (
            "Integrate conscious breathing exercises with meditation to enhance recovery and mental clarity."
        ),
        "Injury Prevention & Joint Health Workout": (
            "A low-impact routine focused on strengthening the muscles around your joints and promoting long-term joint health."
        )
    },
    "Advanced & Special Focus": {
        "Military-Style Fitness for Women": (
            "This plan uses techniques inspired by military training to challenge your strength, endurance, and mental toughness."
        ),
        "Endurance & Cardio Boost (Longer Workouts)": (
            "A more extended routine focusing on boosting cardio endurance and overall stamina through progressive training."
        ),
        "Marathon & Running Strength Routine": (
            "Designed for runners, this plan emphasizes strengthening key muscle groups to improve running performance and injury resistance."
        ),
        "Pregnancy-Safe Strength Workout": (
            "A specialized plan that accommodates the needs of pregnant women by focusing on safe, moderate strength training and stability exercises."
        ),
        "Post-Pregnancy Weight Loss & Strength": (
            "Focus on regaining strength and shedding post-pregnancy weight with a carefully tailored program that considers recovery needs."
        ),
        "Boxing & Combat Fitness for Women": (
            "Combine elements of boxing and combat training for a high-intensity workout that builds strength and confidence."
        ),
        "Grip Strength & Handstand Training": (
            "Challenge your upper body and improve balance with exercises that focus on grip strength and handstand progressions."
        ),
        "Home-Based CrossFit for Women": (
            "Experience a CrossFit-inspired workout at home designed to boost overall strength, stamina, and metabolic conditioning."
        ),
        "Bikini Body Challenge (4-Week Plan)": (
            "A dedicated 4-week challenge aimed at toning and sculpting your body with a mix of cardio, strength, and flexibility exercises."
        ),
        "Strong & Confident (Mind & Body Training)": (
            "A holistic approach to fitness that enhances both physical strength and mental confidence through an integrated training routine."
        )
    }
    }
    
    st.sidebar.header("Home WorkOut Plans: ")
    gender = st.sidebar.selectbox("Select Your Gender", options=["Men", "Women"])

    if gender == "Men":
        st.header("Home Workout Plans for Men")
        category = st.sidebar.selectbox("Select a Category", options=list(men_workouts.keys()))
        plan_name = st.sidebar.selectbox("Select a Plan", options=list(men_workouts[category].keys()))
        st.subheader(plan_name)
        st.markdown(men_workouts[category][plan_name])
    else:
        st.header("Home Workout Plans for Women")
        category = st.sidebar.selectbox("Select a Category", options=list(women_workouts.keys()))
        plan_name = st.sidebar.selectbox("Select a Plan", options=list(women_workouts[category].keys()))
        st.subheader(plan_name)
        st.markdown(women_workouts[category][plan_name])

    st.write("---")
    st.header("INFORMATIONS:")
                
    st.sidebar.header("User Input Parameters: ")

    def user_input_features():
        age = st.sidebar.slider("Age: ", 10, 100, 30)
        bmi = st.sidebar.slider("BMI: ", 15, 40, 20)
        duration = st.sidebar.slider("Duration (min): ", 0, 180, 15)
        heart_rate = st.sidebar.slider("Heart Rate: ", 60, 130, 80)
        body_temp = st.sidebar.slider("Body Temperature (C): ", 36, 42, 38)
        gender_button = st.sidebar.radio("Gender: ", ("Male", "Female"))

        gender = 1 if gender_button == "Male" else 0

        # Use column names to match the training data
        data_model = {
            "Age": age,
            "BMI": bmi,
            "Duration": duration,
            "Heart_Rate": heart_rate,
            "Body_Temp": body_temp,
            "Gender_male": gender  # Gender is encoded as 1 for male, 0 for female
        }

        features = pd.DataFrame(data_model, index=[0])
        return features

    df = user_input_features()
    st.header("Your Parameters: ")
    latest_iteration = st.empty()
    bar = st.progress(0)
    for i in range(100):
        bar.progress(i + 1)
        time.sleep(0.01)
    st.write(df)

    # Load and preprocess data
    calories = pd.read_csv("calories.csv")
    exercise = pd.read_csv("exercise.csv")

    exercise_df = exercise.merge(calories, on="User_ID")
    exercise_df.drop(columns="User_ID", inplace=True)

    exercise_train_data, exercise_test_data = train_test_split(exercise_df, test_size=0.2, random_state=1)

    # Add BMI column to both training and test sets
    for data in [exercise_train_data, exercise_test_data]:
        data["BMI"] = data["Weight"] / ((data["Height"] / 100) ** 2)
        data["BMI"] = round(data["BMI"], 2)
 
    # Prepare the training and testing sets
    exercise_train_data = exercise_train_data[["Gender", "Age", "BMI", "Duration", "Heart_Rate", "Body_Temp", "Calories"]]
    exercise_test_data = exercise_test_data[["Gender", "Age", "BMI", "Duration", "Heart_Rate", "Body_Temp", "Calories"]]
    exercise_train_data = pd.get_dummies(exercise_train_data, drop_first=True)
    exercise_test_data = pd.get_dummies(exercise_test_data, drop_first=True)

    # Separate features and labels
    X_train = exercise_train_data.drop("Calories", axis=1)
    y_train = exercise_train_data["Calories"]

    X_test = exercise_test_data.drop("Calories", axis=1)
    y_test = exercise_test_data["Calories"]

    # Train the model
    random_reg = RandomForestRegressor(n_estimators=1000, max_features=3, max_depth=6)
    random_reg.fit(X_train, y_train)

    # Align prediction data columns with training data
    df = df.reindex(columns=X_train.columns, fill_value=0)

    # Make prediction
    prediction = random_reg.predict(df)

    st.write("---")
    st.header("Prediction: ")
    latest_iteration = st.empty()
    bar = st.progress(0)
    for i in range(100):
        bar.progress(i + 1)
        time.sleep(0.01)

    st.write(f"{round(prediction[0], 2)} **kilocalories**")

    st.write("---")
    st.header("Similar Results: ")
    latest_iteration = st.empty()
    bar = st.progress(0)
    for i in range(100):
        bar.progress(i + 1)
        time.sleep(0.01)

    # Find similar results based on predicted calories
    calorie_range = [prediction[0] - 10, prediction[0] + 10]
    similar_data = exercise_df[(exercise_df["Calories"] >= calorie_range[0]) & (exercise_df["Calories"] <= calorie_range[1])]
    st.write(similar_data.sample(5))

    st.write("---")
    st.header("General Information: ")

    # Boolean logic for age, duration, etc., compared to the user's input
    boolean_age = (exercise_df["Age"] < df["Age"].values[0]).tolist()
    boolean_duration = (exercise_df["Duration"] < df["Duration"].values[0]).tolist()
    boolean_body_temp = (exercise_df["Body_Temp"] < df["Body_Temp"].values[0]).tolist()
    boolean_heart_rate = (exercise_df["Heart_Rate"] < df["Heart_Rate"].values[0]).tolist()

    st.write("You are older than", round(sum(boolean_age) / len(boolean_age), 2) * 100, "% of other people.")
    st.write("Your exercise duration is higher than", round(sum(boolean_duration) / len(boolean_duration), 2) * 100, "% of other people.")
    st.write("You have a higher heart rate than", round(sum(boolean_heart_rate) / len(boolean_heart_rate), 2) * 100, "% of other people during exercise.")
    st.write("You have a higher body temperature than", round(sum(boolean_body_temp) / len(boolean_body_temp), 2) * 100, "% of other people during exercise.")
     

    if "water_intake" not in st.session_state:
        st.session_state.water_intake = 0
    
    st.write("---")
    st.title("Hydration & Electrolyte Tracker")

    # User input: Water intake (in liters)
    water_today = st.number_input("Enter water intake today (liters):", min_value=0.0, step=0.1)
    if st.button("Log Water Intake"):
        st.session_state.water_intake += water_today
        st.success(f"Total Water Intake Today: {st.session_state.water_intake:.1f} L")

    # Suggest hydration goal based on activity level
    activity_level = st.selectbox("Select your activity level:", ["Low", "Medium", "High"])
    weather_temp = st.slider("Select current temperature (°C):", 0, 50, 25)

    # Hydration recommendation logic
    base_water_need = 2  # Base need (L)
    if activity_level == "Medium":
        base_water_need += 0.5
    elif activity_level == "High":
        base_water_need += 1.0

    if weather_temp > 30:
        base_water_need += 0.5

    st.info(f"Recommended daily water intake: {base_water_need:.1f} L")

    # Reminders
    if st.session_state.water_intake < base_water_need:
        st.warning("You need to drink more water!")

    if st.button("Logout"):
        st.session_state.login = False
        st.session_state.current_user = None
        st.rerun() 
        